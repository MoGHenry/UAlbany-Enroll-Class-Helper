# HDD

* Name: Henry Qiu, Yunrui Huang, Jianxiang Huang
* Course: CSI 418Y Software Engineering
* Professor: Mei-Hwa Chen
* TA: Ninad Chaudhari
* Term: Fall 2022
* Date: 11/11/22

## Individual Contribution

Our team works on both diagram together

Henry Qiu draws the diagram with starUML

Yunrui Huang and Jianxinag Huang shares their information to complete the diagram